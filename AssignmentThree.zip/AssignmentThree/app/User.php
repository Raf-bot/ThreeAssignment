<?php
    use Framework\Domain;

    class User implements Domain #
    {
        private $UserName;
        private $email;
        private $password;

        function __construct($u, $em, $word)

        {
            $this->UserName = $u;
            $this->email = $em;
            $this->password = $word;
        }

        public function getUsername()
        {
            return $this->UserName;
        }

        public function getEmail()
        {
            return $this->email;
        }

        public function getPassword()
        {
            return $this->password;
        }
}

?>
