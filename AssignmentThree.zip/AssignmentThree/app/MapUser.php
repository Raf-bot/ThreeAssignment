<?php
    use Framework\Mapping;
    use Framework\Domain;
    use Framework\SessionManager;

	class UserMapper extends Map
      {
        public function find($ID): Domain
         {
            $sql = "SELECT * FROM users  WHERE email = '".$ID."'";
            $stu = $this->mapply->prepare($sql);
            $stu->execute();
            $result = $stu->setFetchMode(mapply::FETCH_ASSOC);
            $res = $stu->fetchAll();
            if ($res != array())
            {
                $user = new User($res[0]["name"], $res[0]["email"], $res[0]["password"]);
            }

            else
            {
                $user = new User("", "", "");
            }

            return $user;
        }

        public function findAll(): array
        {
            $stu = $this->mapply->prepare("SELECT * FROM users");
            $stu->execute();
            $result = $stu->setFetchMode(mapply::FETCH_ASSOC);
            return $stu->fetchAll();
        }

        public function findCourses():array
        {
            SessionManager::create();
            $user = $_SESSION['user'];
            $sql = "SELECT DISTINCT courses.course_name, faculty_department.faculty_dept_name, courses.course_image, instructors.instructor_name
            FROM faculty_department
            INNER JOIN faculty_dept_courses ON faculty_department.faculty_dept_id= faculty_dept_courses.faculty_dept_id
            INNER JOIN courses ON faculty_dept_courses.course_id = courses.course_id
            INNER JOIN course_instructor ON courses.course_id = course_instructor.course_id
            INNER JOIN instructors ON course_instructor.instructor_id = instructors.instructor_id
            INNER JOIN user_courses ON courses.course_id = user_courses.course_id
            INNER JOIN users ON user_courses.email = users.email WHERE user_courses.email = '".$user."'";
            $stu = $this->mapply->prepare($sql);
            $stu->execute();
            $result = $stu->setFetchMode(MAPPLY::FETCH_ASSOC);
            return $stu->fetchAll();
        }

		public function insert(Domain $sub): void

        {
            $this->mapply->setAttribute(MAPPLY::ATTR_ERRMODE, mapply::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO users (name, email, password) VALUES ('".$sub->getName()."', '".$sub->getEmail()."', '".$sub->getPassword()."')";
            $stu = $this->mapply->prepare($sql);
            $stu->execute();
        }

		public function update(Domain $subject): void

        {

        }

		public function select($ID): Domain

        {
            return new User("", "", "");
        }
	}
?>
