<?php
    namespace Framework;

    class Course implements Domain
    {

        private $csName;
        private $csDesc;
        private $csImg;
        private $facDeptN;
        private $lecturer ;

        function __construct($x, $w, $y, $z, $a) {
            $this->csName = $x;
            $this->csDesc = $w;
            $this->csImg = $y;
            $this->facDeptN = $z;
            $this->lecturer = $a;
        }

          public function getCourse()
          {
              return $this->csName;
          }

          public function getCourseDescription()
          {
              return $this->csDesc;
          }

          public function getImageofCourse()
          {
              return $this->csImg;
          }

          public function getDepartmentName()
          {
              return $this->facDeptN;
          }

          public function getNameofLecturer()
          {
              return $this->lecturer;
          }
}

?>
