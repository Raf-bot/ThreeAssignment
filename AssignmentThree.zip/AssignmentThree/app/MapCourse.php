<?php
    use Framework\Mapping;
    use Framework\Course;
    use Framework\Domain;

	class CourseMapper extends Mapp
  {

        public function find($ID): Domain
        {
            $sql = "SELECT courses.course_name, courses.course_description, courses.course_image, instructors.instructor_name
                FROM courses
                INNER JOIN course_instructor ON courses.course_id = course_instructor.course_id
                INNER JOIN instructors ON course_instructor.instructor_id = instructors.instructor_id
                WHERE courses.course_id = '".$id."'";
            $stu = $this->work->prepare($sql);
            $stu->execute();
            $result = $stu->setFetchMode(MAPPLY::FETCH_ASSOC);
            $outcome = $stu->fetchAll();
            $path = new Course($res[0]["course_name"], $res[0]["course_description"], $res[0]["course_image"], "", $res[0]["instructor_name"]);
            return $path;
        }

        public function findAll(): array
        {
            $stu = $this->work->prepare("SELECT * FROM courses");
            $stu->execute();
            $result = $stu->setFetchMode(MAPPLY::FETCH_ASSOC);
            return $stu->fetchAll();
        }

        public function findMostPopular():array
        {
            $sql = "SELECT courses.course_name, courses.course_description, courses.course_image, instructors.instructor_name
                FROM courses
                INNER JOIN course_instructor ON courses.course_id = course_instructor.course_id
                INNER JOIN instructors ON course_instructor.instructor_id = instructors.instructor_id
                ORDER BY courses.course_access_count DESC
                LIMIT 8";
            $stu = $this->mapply->prepare($sql);
            $stu->execute();
            $result = $stu->setFetchMode(MAPPLY::FETCH_ASSOC);
            return $stu->fetchAll();
        }

        public function findCourses():array
        {
            $sql = "SELECT DISTINCT courses.course_name, faculty_department.faculty_dept_name, courses.course_image, instructors.instructor_name
            FROM faculty_department
            INNER JOIN faculty_dept_courses ON faculty_department.faculty_dept_id= faculty_dept_courses.faculty_dept_id
            INNER JOIN courses ON faculty_dept_courses.course_id = courses.course_id
            INNER JOIN course_instructor ON courses.course_id = course_instructor.course_id
            INNER JOIN instructors ON course_instructor.instructor_id = instructors.instructor_id";
            $stu = $this->mapply->prepare($sql);
            $stu->execute();
            $result = $stu->setFetchMode(MAPPLY::FETCH_ASSOC);
            return $stu->fetchAll();
        }


        public function select($id): Domain
          {
                return new Course("", "", "", "", "");
          }

        public function insert(Domain $sub): void
        {  }

        public function update(Domain $subject): void
        {   }
	}
?>
