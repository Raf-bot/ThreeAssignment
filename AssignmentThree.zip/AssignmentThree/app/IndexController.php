<?php

class IndexController
{

  public function run()
  {

    $v = new View();
    $v->setTemplate(TPL_DIR . '/index.tpl.php');

    $this->setModel(new IndexModel());
    $this->setView($v);

    $this->model->attach($this->view);

    $data = $this->model->getAll();

    $this->model->updateTheChangedData($data);

    $this->model->notify();

  }

  public function execute(CommandContext $context): bool
  {
    $this->data = $context;
    $this->run();
    return true;
  }
}


?>
