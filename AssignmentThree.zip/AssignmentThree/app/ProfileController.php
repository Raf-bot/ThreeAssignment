<?php
class ProfileController extends Controller_Abstract
{

    public function run()
    {
        SessionManager::create();

        $sess = new SessionManager();
        $sess->add('user', 'testuser');
        $sess->remove('user');
        $v = new View();
        $v->setTemplate(TPL_DIR . '/profile.tpl.php')

        $this->setModel(new ProfileModel());
        $this->setView($v);

        $this->model->attach($this->view);

        $user = $sess->see('user');

        if($sess->accessible($user, 'profile'))
        {

        $data = $this->model->getALL();

        $this->model->updateThechangedData($data);

        $this->model->notify();
      }
       else{
            $v->setTemplate(TPL_DIR . '/login.tpl.php');
            $v->display();
       }
    }
}




?>
