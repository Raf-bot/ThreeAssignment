<?php
use PHPUnit\Framework\TestCase;
require '../SessionManager.php';

class SessionManagerTest extends TestCase
{
    public function testSessionObjectIsCreated extends() : void
    {
        $this->assertIsObject(new SessionManager);
    }

    public function testSessionManagerStaticMethod() : void
    {
      $method = new ReflectionMethod('SessionManager', 'clear');
      $this->assertTrue($method->isStatic(),'Methods are not static');
    }

    public function testSessionContainer() : void
    {
      SessionManager::create();
      $this->assertArrayHasKey('container', $_SESSION);
      $this->assertIsArray($_SESSION['container'])
    }
}
