<?php
define("ROOT_DIR",  'C:\xampp\htdocs\COMP3385\AssignmentTwo');
define("APP_DIR", ROOT_DIR . "\app");
define("FRAMEWORK_DIR", ROOT_DIR . '\framework');
define("TPL_DIR", ROOT_DIR . '\tpl');
define("DATA_DIR", ROOT_DIR . '\data');

 ?>
