<?php
class IndexController extends PageController_Abstract
{

    public function run()
    {
      $v = new View();
      $v->setTemplate(TPL_DIR . '/index.tpl.php')

      $this->SETmODEL(new IndexModel());
      $this->setView($v);

      $this->model->attach($this->view);

      $data = $this->model->getAll();

      $this->model->updateThechangeData($data);

      $this->model->notify();
    }
}




 ?>
