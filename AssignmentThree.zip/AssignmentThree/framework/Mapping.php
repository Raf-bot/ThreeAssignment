<?php
	namespace Framework;

	abstract class Map {
        protected $mapply;

		public function __construct() {
			$moocConnection = new MOOCConnection();
			$this->work = $moocConnection->createConnection();
		}


		    abstract public function insert(Domain $sub): void;
		    abstract public function update(Domain $subject): void;
        abstract public function find($ID): Domain;
        abstract public function findAll(): array;
        abstract public function select($ID): Domain;
	}
?>
