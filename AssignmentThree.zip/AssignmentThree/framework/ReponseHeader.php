<?php

namespace Work

class ReponseHeader implements Reponse_Interface
{

  public function addEntries(array $entries): bool
  {
    return false;
  }

  public function showEntriess(int $start, int $end): string
  {
    return "";
  }

  public function showEntry(int $i): string
  {
    return '';
  }

}



 ?>
