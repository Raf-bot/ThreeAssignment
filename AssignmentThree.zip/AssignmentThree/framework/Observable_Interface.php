<?php

namespace Work

abstract class Observer_Interface implements SplObserver
{
    private $observable;

    function construct(Observable $observable)
    {
        $this->observable = $observable;
        $observable->attach($this);
    }

    function update(SplSubject $subject)
    {
        if ($subject === $this->observable) {
            $this->doUpdate($subject);
        }
    }

    abstract function doUpdate(Observable $observable);
}

class ConcreteObserver extends Observer_Model
{
    function doUpdate(Observable $observable)
    {
      return $this->$observable;
    }
}

$observable = new Observable();
new ConcreteObserver($observable);


?>
