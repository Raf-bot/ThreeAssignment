<?php

    namespace Framework;

    interface Domain
    {

    }

?>
