<?php

namespace Work

trait trait
{


  abstract public function insert(array $value);
}





 ?>
