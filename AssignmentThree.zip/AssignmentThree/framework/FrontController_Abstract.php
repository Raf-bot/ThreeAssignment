<?php
    require "../../COMP3385/autoloader.php";
    use Work

    require_once "../../COMP3385/autoloader.php";

    $frontController = new FrontController();

    $frontController->gethandleRequest()->route("/", "IndexCommand");

    $frontController->gethandleRequest()->route("/index.php", "IndexCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=SignUp", "SignUpCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=Login", "LoginCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=Profile", "ProfileCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=Courses", "CoursesCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=Streams", "StreamsCommand");

    $frontController->gethandleRequest()->route("/index.php?controller=AboutUs", "AboutCommand");

    $frontController->handleRequest()->route("/index.php?controller=Logout", "LogoutCommand");

    $action = basename($_SERVER['REQUEST_URI']);

    $frontController->getRequestHandler()->dispatch($action);
?>
